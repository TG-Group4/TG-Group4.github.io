"use strict";

let gl;
let program;
let indexType = null;
let rotationAngle = 0.0;
let rotationMatrixLoc;
let normalBuffer;
let shadingModeLoc;

function parseOFF(data){
        setStatus('Parsing OFF file...');
        const lines = data.replace(/\r/g, ' ').split(/\s+/).filter(t => t.length > 0);
        let i = 0;

        if (lines[i] && lines[i].toUpperCase() === 'OFF') {
            i++;
        }

        const numVert = parseInt(lines[i++] || '0');
        const numFaces = parseInt(lines[i++] || '0');
        const numEdges = parseInt(lines[i++] || '0');
        
        const vertices = [];
        const faces = [];

        for (let v = 0; v < numVert; v++) {
            const x = parseFloat(lines[i++] || '0');
            const y = parseFloat(lines[i++] || '0');
            const z = parseFloat(lines[i++] || '0');
            vertices.push({ x, y, z });
        }

        for (let f = 0; f < numFaces; f++) {
            const faceSize = parseInt(lines[i++] || '0');
            const faceIndices = [];
            for (let fi = 0; fi < faceSize; fi++) {
                faceIndices.push(parseInt(lines[i++] || '0'));
            }
            if (faceIndices.length >= 3) {
                faces.push(faceIndices);
            }
        }

        console.log('Vertices:', vertices.length, 'Faces:', faces.length);
        if (vertices.length === 0 || faces.length === 0) {
            console.error('OFF file parsing failed: no vertices or faces found.');
            setStatus('OFF parse failed: no vertices or faces.');
            return;
        }

        tri = faces;
        vert = vertices;
        
        updateCameraForModel(vert);
        setupBuffers();
        render();
    }
    
    let tri = [];
    let vert = [];
    let vertexBuffer, indexBuffer;
    let numIndices = 0;
    

    function CalculateSurfaceNormal (faces, vertices, numFaces){
        const Normal = [];
        for(let i = 0; i < numFaces; i++){
            const a = vertices[faces[i][0]];
            const b = vertices[faces[i][1]];
            const c = vertices[faces[i][2]];
            
            // Create vectors relative to a
            const u = {x: b.x - a.x, y: b.y - a.y, z: b.z - a.z};
            const v = {x: c.x - a.x, y: c.y - a.y, z: c.z - a.z};

            const x = (u.y * v.z) - (u.z * v.y);
            const y = (u.z * v.x) - (u.x * v.z);
            const z = (u.x * v.y) - (u.y * v.x);
            Normal.push({x, y, z});
        }
        
        console.log('Normals', Normal);
        tri = faces;
        vert = vertices; 
        setupBuffers();
        render();
    }
    
    
    

    const near = -0.2;
    const far = 1.0;
    const left = -0.2;
    const right = 0.2;
    const tops = 0.2;
    const bottom = -0.8;

    var modelViewMatrix, projectionMatrix;
    var modelViewMatrixLoc, projectionMatrixLoc;
    
    const eye = vec3(0.0, -2.0, -0.05);
    const at = vec3(0.0, -2.0, 0.0);
    const up = vec3(0.0, 1.0, 0.0);

    function updateCameraForModel(vertices) {
        let minX = Infinity, minY = Infinity, minZ = Infinity;
        let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;

        for (let v of vertices) {
            minX = Math.min(minX, v.x);
            minY = Math.min(minY, v.y);
            minZ = Math.min(minZ, v.z);
            maxX = Math.max(maxX, v.x);
            maxY = Math.max(maxY, v.y);
            maxZ = Math.max(maxZ, v.z);
        }

        const centerX = (minX + maxX) / 2;
        const centerY = (minY + maxY) / 4;
        const centerZ = (minZ + maxZ) / 2;
        const spanX = maxX - minX;
        const spanY = maxY - minY;
        const spanZ = maxZ - minZ;
        const maxSpan = Math.max(spanX, spanY, spanZ, 0.001);

        const padding = 0.2 * maxSpan;
        const halfSpan = maxSpan / 2 + padding;

        modelViewMatrix = lookAt(
            vec3(centerX, centerY, centerZ - maxSpan * 0.5),
            vec3(centerX, centerY, centerZ),
            up
        );

        projectionMatrix = ortho(
            -halfSpan + centerX,
            halfSpan + centerX,
            -halfSpan + centerY,
            halfSpan + centerY,
            -maxSpan * 2,
            maxSpan * 2
        );
    }

    function setupBuffers() {
        const vertexData = new Float32Array(vert.length * 3);
        for (let i = 0; i < vert.length; i++) {
            vertexData[i * 3] = vert[i].x;
            vertexData[i * 3 + 1] = vert[i].y;
            vertexData[i * 3 + 2] = vert[i].z;
        }

        const vertexNormals = Array.from({ length: vert.length }, () => ({ x: 0, y: 0, z: 0 }));
        const indexData = [];
        for (let face of tri) {
            for (let i = 1; i + 1 < face.length; i++) {
                const i0 = face[0];
                const i1 = face[i];
                const i2 = face[i + 1];
                indexData.push(i0, i1, i2);
                const p0 = vert[i0];
                const p1 = vert[i1];
                const p2 = vert[i2];
                const u = { x: p1.x - p0.x, y: p1.y - p0.y, z: p1.z - p0.z };
                const v = { x: p2.x - p0.x, y: p2.y - p0.y, z: p2.z - p0.z };
                const normal = {
                    x: u.y * v.z - u.z * v.y,
                    y: u.z * v.x - u.x * v.z,
                    z: u.x * v.y - u.y * v.x
                };
                for (let idx of [i0, i1, i2]) {
                    vertexNormals[idx].x += normal.x;
                    vertexNormals[idx].y += normal.y;
                    vertexNormals[idx].z += normal.z;
                }
            }
        }

        const normalData = new Float32Array(vert.length * 3);
        for (let i = 0; i < vert.length; i++) {
            const n = vertexNormals[i];
            const len = Math.hypot(n.x, n.y, n.z) || 1.0;
            normalData[i * 3] = n.x / len;
            normalData[i * 3 + 1] = n.y / len;
            normalData[i * 3 + 2] = n.z / len;
        }

        numIndices = indexData.length;
        indexType = numIndices > 65535 ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT;
        const indexArray = indexType === gl.UNSIGNED_INT ? new Uint32Array(indexData) : new Uint16Array(indexData);

        console.log('Buffer data:', vert.length, 'vertices,', numIndices, 'indices,', indexType === gl.UNSIGNED_INT ? 'UNSIGNED_INT' : 'UNSIGNED_SHORT');

        vertexBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, vertexData, gl.STATIC_DRAW);

        normalBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
        gl.bufferData(gl.ARRAY_BUFFER, normalData, gl.STATIC_DRAW);

        var aPosition = gl.getAttribLocation(program, "aPosition");
        
        gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
        gl.vertexAttribPointer(aPosition, 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(aPosition);

        var aNormal = gl.getAttribLocation(program, "aNormal");
        
        gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
        gl.vertexAttribPointer(aNormal, 3, gl.FLOAT, false, 0, 0);
        gl.enableVertexAttribArray(aNormal);

        indexBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, indexArray, gl.STATIC_DRAW);
    }
    function initShaders(gl, vertexShaderId, fragmentShaderId) {
        const vertElement = document.getElementById(vertexShaderId);
        const fragElement = document.getElementById(fragmentShaderId);

        const vertShader = loadShader(gl, gl.VERTEX_SHADER, vertElement.textContent);
        const fragShader = loadShader(gl, gl.FRAGMENT_SHADER, fragElement.textContent);

        const shaderProgram = gl.createProgram();
        gl.attachShader(shaderProgram, vertShader);
        gl.attachShader(shaderProgram, fragShader);
        gl.linkProgram(shaderProgram);

    return shaderProgram;
    }
    function loadShader(gl, type, source) {
        const shader = gl.createShader(type);
        let sourceText = typeof source === 'string' ? source : '';
        sourceText = sourceText.replace(/^[\uFEFF\s]*/u, '');
        gl.shaderSource(shader, sourceText);
        gl.compileShader(shader);

        return shader;
    }


window.onload = function init()
{

    let canvas = document.getElementById( "gl-canvas" );
    gl = canvas.getContext('webgl2');
    if (!gl) { alert( "WebGL 2.0 isn't available" ); }

    const fileInput = document.getElementById('fileInput');
    console.log('fileInput element', fileInput);
    if (fileInput) {
        fileInput.addEventListener('change', function selectedFileChanged() {
        if (this.files.length === 0) {
            console.log('No file selected.');
            setStatus('No file selected.');
            return;
        }

        const file = this.files[0];
        console.log('Selected file:', file.name, file.size, 'bytes');
        setStatus('Selected file: ' + file.name);

        const reader = new FileReader();
        reader.onload = function fileReadCompleted() {
            parseOFF(reader.result);
        };
        reader.readAsText(file);
    });
    }

    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 0.2, 0.2, 0.2, 1.0 );
    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.PROGRAM_POINT_SIZE);
    gl.clearDepth(1.0);

    //  Load shaders and initialize attribute buffers

    program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );

    modelViewMatrixLoc = gl.getUniformLocation(program, "uModelViewMatrix");
    projectionMatrixLoc = gl.getUniformLocation(program, "uProjectionMatrix");
    rotationMatrixLoc = gl.getUniformLocation(program, "uRotationMatrix");
    shadingModeLoc = gl.getUniformLocation(program, "uShadingMode");

    const lightPositionLoc = gl.getUniformLocation(program, "uLightPosition");
    const ambientProductLoc = gl.getUniformLocation(program, "uAmbientProduct");
    const diffuseProductLoc = gl.getUniformLocation(program, "uDiffuseProduct");
    const specularProductLoc = gl.getUniformLocation(program, "uSpecularProduct");
    const shininessLoc = gl.getUniformLocation(program, "uShininess");

    const lightPosition = vec4(0.0, 0.0, 1.0, 0.0);
    const lightAmbient = vec4(0.2, 0.2, 0.2, 1.0);
    const lightDiffuse = vec4(1.0, 1.0, 1.0, 1.0);
    const lightSpecular = vec4(1.0, 1.0, 1.0, 1.0);
    const materialAmbient = vec4(0.24725, 0.1995, 0.0745, 1.0);
    const materialDiffuse = vec4(0.75164, 0.60648, 0.22648, 1.0);
    const materialSpecular = vec4(0.628281, 0.555802, 0.366065, 1.0);
    const shininess = 24.2;

    const ambientProduct = [
        lightAmbient[0] * materialAmbient[0],
        lightAmbient[1] * materialAmbient[1],
        lightAmbient[2] * materialAmbient[2],
        lightAmbient[3] * materialAmbient[3]
    ];
    const diffuseProduct = [
        lightDiffuse[0] * materialDiffuse[0],
        lightDiffuse[1] * materialDiffuse[1],
        lightDiffuse[2] * materialDiffuse[2],
        lightDiffuse[3] * materialDiffuse[3]
    ];
    const specularProduct = [
        lightSpecular[0] * materialSpecular[0],
        lightSpecular[1] * materialSpecular[1],
        lightSpecular[2] * materialSpecular[2],
        lightSpecular[3] * materialSpecular[3]
    ];

    gl.uniform4fv(lightPositionLoc, flatten(lightPosition));
    gl.uniform4fv(ambientProductLoc, flatten(ambientProduct));
    gl.uniform4fv(diffuseProductLoc, flatten(diffuseProduct));
    gl.uniform4fv(specularProductLoc, flatten(specularProduct));
    gl.uniform1f(shininessLoc, shininess);
    gl.uniform1i(shadingModeLoc, 0);

    const shadingSelect = document.getElementById('shadingMode');
    if (shadingSelect) {
        shadingSelect.addEventListener('change', function() {
            const mode = parseInt(this.value, 10);
            gl.uniform1i(shadingModeLoc, mode);
            setStatus('Shading mode: ' + (mode === 0 ? 'Gouraud' : 'Phong'));
        });
    }

    modelViewMatrix = lookAt(eye, at , up);
    projectionMatrix = ortho(left, right, bottom, tops, near, far);
    setStatus('Ready. Load an OFF file.');
    requestAnimationFrame(render);
};


function setStatus(message) {
    const status = document.getElementById('status');
    if (status) {
        status.textContent = message;
    }
}

function render() {
    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT );

    rotationAngle += 0.005;
    if (rotationMatrixLoc) {
        const rotationMatrix = rotateY(rotationAngle);
        gl.uniformMatrix4fv(rotationMatrixLoc, false, flatten(rotationMatrix));
    }

    gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
    gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix));
    if (shadingModeLoc) {
        const shadingSelect = document.getElementById('shadingMode');
        if (shadingSelect) {
            gl.uniform1i(shadingModeLoc, parseInt(shadingSelect.value, 10));
        }
    }
    gl.drawElements(gl.TRIANGLES, numIndices, indexType, 0);
        
    requestAnimationFrame(render);
}
