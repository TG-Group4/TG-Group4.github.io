"use strict";





function vec3(x, y, z) {
    return [x, y, z];
}

function vec4(x, y, z, w) {
    return [x, y, z, w];
}

function normalize(v) {
    const len = Math.hypot(v[0], v[1], v[2]);
    return len === 0 ? [0, 0, 0] : [v[0] / len, v[1] / len, v[2] / len];
}

function cross(u, v) {
    return [
        u[1] * v[2] - u[2] * v[1],
        u[2] * v[0] - u[0] * v[2],
        u[0] * v[1] - u[1] * v[0]
    ];
}

function subtract(u, v) {
    return [u[0] - v[0], u[1] - v[1], u[2] - v[2]];
}

function dot(u, v) {
    return u[0] * v[0] + u[1] * v[1] + u[2] * v[2];
}

function lookAt(eye, at, up) {
    const f = normalize(subtract(at, eye));
    const s = normalize(cross(f, up));
    const u = cross(s, f);

    return new Float32Array([
        s[0], s[1], s[2], 0,
        u[0], u[1], u[2], 0,
        -f[0], -f[1], -f[2], 0,
        -dot(s, eye), -dot(u, eye), dot(f, eye), 1
    ]);
}

function ortho(left, right, bottom, top, near, far) {
    const tx = -(right + left) / (right - left);
    const ty = -(top + bottom) / (top - bottom);
    const tz = -(far + near) / (far - near);

    return new Float32Array([
        2 / (right - left), 0, 0, 0,
        0, 2 / (top - bottom), 0, 0,
        0, 0, -2 / (far - near), 0,
        tx, ty, tz, 1
    ]);
}

function rotateY(theta) {
    const c = Math.cos(theta);
    const s = Math.sin(theta);
    return new Float32Array([
        c, 0, s, 0,
        0, 1, 0, 0,
        -s, 0, c, 0,
        0, 0, 0, 1
    ]);
}

function flatten(matrix) {
    if (matrix instanceof Float32Array) {
        return matrix;
    }
    return new Float32Array(matrix);
}
